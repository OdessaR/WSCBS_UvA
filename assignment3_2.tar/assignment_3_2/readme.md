# Kubernetes yml files assignment 3
The files ending on `-service.yml` are describing the Kubernetes services. The files ending on `-deployment.yml` are describing the deployment for Kubernetes.

The files starting with `url-shortner` describe the configuration for the url shortner application. The files starting with `authentication-system` describe the authentication system configuration.